package com.example.brasa_hacks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.TextView;

public class FirstChoiceActivity extends AppCompatActivity {
    TextView txtName;
    ProgressBar pbStrength, pbSpeed, pbOverall;
    RadioButton rbGoleiro, rbZaga, rbMeia, rbAtaque;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_choice);
        setTitle("FutLife");

        txtName = findViewById(R.id.txtName);
        pbStrength = findViewById(R.id.pbStrength);
        pbOverall = findViewById(R.id.pbOverall);
        pbSpeed = findViewById(R.id.pbSpeed);
        rbAtaque = findViewById(R.id.rbAtacante);
        rbGoleiro = findViewById(R.id.rbGoalie);
        rbMeia = findViewById(R.id.rbMeio);
        rbZaga = findViewById(R.id.rbZag);


        Intent intent = getIntent();
        final User user = (User) intent.getSerializableExtra("Player");

        String msg = "Bem-vindo " + user.getName() + "!\nHoje você começa sua jornada ao topo!";
        txtName.setText(msg);
        pbSpeed.setProgress(user.getSpeed());
        pbOverall.setProgress(user.getOverall());
        pbStrength.setProgress(user.getStrength());

        rbGoleiro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.setPos("Goleiro");
                Intent intent = new Intent(getApplicationContext(), PickTeamActivity.class);
                intent.putExtra("Player", user);
                startActivity(intent);
            }
        });

        rbZaga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.setPos("Zagueiro");
                Intent intent = new Intent(getApplicationContext(), PickTeamActivity.class);
                intent.putExtra("Player", user);
                startActivity(intent);
            }
        });

        rbMeia.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.setPos("Meia");
                Intent intent = new Intent(getApplicationContext(), PickTeamActivity.class);
                intent.putExtra("Player", user);
                startActivity(intent);
            }
        });

        rbAtaque.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user.setPos("Atacante");
                Intent intent = new Intent(getApplicationContext(), PickTeamActivity.class);
                intent.putExtra("Player", user);
                startActivity(intent);
            }
        });
    }
}