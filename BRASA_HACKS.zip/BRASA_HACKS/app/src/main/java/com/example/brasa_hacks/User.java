package com.example.brasa_hacks;

import java.io.Serializable;
import java.util.Random;

public class User implements Serializable {
    boolean isMale;
    int overall, speed, strength;
    String name, pos;

    public User(boolean isMale, String name) {
        this.isMale = isMale;
        this.name = name;

        Random rand = new Random();
        int overall = rand.nextInt(101);
        int money = rand.nextInt(101);
        int strength = rand.nextInt(101);

        this.setOverall(overall);
        this.setSpeed(money);
        this.setStrength(strength);
    }

    public int getOverall() {
        return overall;
    }

    public void setOverall(int overall) {
        this.overall = overall;
    }

    public int getSpeed() {
        return speed;
    }

    public void setSpeed(int money) {
        this.speed = money;
    }

    public int getStrength() {
        return strength;
    }

    public void setStrength(int strength) {
        this.strength = strength;
    }

    public boolean isMale() {
        return isMale;
    }

    public void setMale(boolean male) {
        isMale = male;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPos() {
        return pos;
    }

    public void setPos(String pos) {
        this.pos = pos;
    }
}
