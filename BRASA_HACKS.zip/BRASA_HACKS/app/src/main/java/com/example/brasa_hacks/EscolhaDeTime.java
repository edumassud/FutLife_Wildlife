package com.example.brasa_hacks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class EscolhaDeTime extends AppCompatActivity {
    Button bt1, bt2, bt3, bt4;
    TextView txtTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_escolha_de_time);
        setTitle("FutLife");

        bt1 = findViewById(R.id.btChoice1);
        bt2 = findViewById(R.id.btChoice2);
        bt3 = findViewById(R.id.btChoice3);
        bt4 = findViewById(R.id.btChoice4);

        txtTitle = findViewById(R.id.txtResult);

        Intent intent = getIntent();
        final User user = (User) intent.getSerializableExtra("User");
        int qual = (int) intent.getSerializableExtra("Qualidade");

        int result = user.getOverall() + user.getSpeed() + user.getStrength() + qual;

        if (result > 350) {
            bt1.setText("Santos");
            bt2.setText("Flamengo");
            bt3.setText("Palmeiras");
            bt4.setText("Fluminense");
        } else if (result > 200) {
            bt1.setText("Red Bull Bragantino");
            bt2.setText("Sport Recife");
            bt3.setText("Internacional");
            bt4.setText("Atlético Goianiense");
        } else {
            bt1.setText("Vasco Da Game");
            bt2.setText("Cruzeiro");
            bt3.setText("Botafogo");
            bt4.setText("ceará");
        }
    }
}