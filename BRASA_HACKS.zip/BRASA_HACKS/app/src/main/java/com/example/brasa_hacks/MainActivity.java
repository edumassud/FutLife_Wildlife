package com.example.brasa_hacks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Parcelable;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;

public class MainActivity extends AppCompatActivity {
    Button btFemale, btMale;
    TextInputEditText txtName;

    User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("FutLife");

        btFemale = findViewById(R.id.btFemale);
        btMale = findViewById(R.id.btMale);
        txtName = findViewById(R.id.txtName);


        btFemale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtName.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Digite um nome pra sua jogadora!", Toast.LENGTH_SHORT).show();
                } else {
                    user = new User(false, txtName.getText().toString());
                    Intent intent = new Intent(getApplicationContext(), FirstChoiceActivity.class);
                    intent.putExtra("Player", user);
                    startActivity(intent);
                }
            }
        });

        btMale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (txtName.getText().toString().isEmpty()) {
                    Toast.makeText(MainActivity.this, "Digite um nome pro seu jogador!", Toast.LENGTH_SHORT).show();
                } else {
                    user = new User(true, txtName.getText().toString());
                    Intent intent = new Intent(getApplicationContext(), FirstChoiceActivity.class);
                    intent.putExtra("Player", user);
                    startActivity(intent);
                }
            }
        });
    }
}