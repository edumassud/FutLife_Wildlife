package com.example.brasa_hacks;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Random;

public class PickTeamActivity extends AppCompatActivity {
    ProgressBar pbStrength, pbSpeed, pbOverall;
    Button bt1, bt2, bt3, bt4, btResults;
    TextView txtTitle, txtPrompt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pick_team);
        setTitle("FutLife");

        pbStrength = findViewById(R.id.pbStrength);
        pbOverall = findViewById(R.id.pbOverall);
        pbSpeed = findViewById(R.id.pbSpeed);
        bt1 = findViewById(R.id.btChoice1);
        bt2 = findViewById(R.id.btChoice2);
        bt3 = findViewById(R.id.btChoice3);
        bt4 = findViewById(R.id.btChoice4);
        txtTitle = findViewById(R.id.txtTitle);
        txtPrompt = findViewById(R.id.txtPrompt);
        btResults = findViewById(R.id.btResults);

        final Intent intent = getIntent();
        final User user = (User) intent.getSerializableExtra("Player");

        pbSpeed.setProgress(user.getSpeed());
        pbOverall.setProgress(user.getOverall());
        pbStrength.setProgress(user.getStrength());
        final Intent intent1 = new Intent(getApplicationContext(), EscolhaDeTime.class);
        btResults.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(intent1);
            }
        });



        bt1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtTitle.setText("Momentos finais!");

                if (user.getPos().equals("Goleiro")) {
                    txtPrompt.setText("O atacante adversário driblo o zagueiro e sofreu uma falta na area! Penalti no ultimo lance do jogo. Se eles marcarem ja era.\nVocê tem a chance de virar a estrela!");
                    bt1.setText("Pular pra direita");
                    bt2.setText(" Pular pra esquerda");
                    bt3.setText("Tira onda do atacante e pular com confiança");
                    bt4.setText("Fica sério e contar no reflexo");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            btResults.setVisibility(View.VISIBLE);
                            Random rand = new Random();
                            int chance = rand.nextInt(101);

                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Salvou o penalti e fez o povo todo aplaudir de pé! Os treinos valeram a pena.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                btResults.setVisibility(View.VISIBLE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Goleiro pra direita bola pra esquerda. Pena");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            btResults.setVisibility(View.VISIBLE);
                            int chance = rand.nextInt(101);

                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Salvou o penalti e fez o povo todo aplaudir de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Goleiro pra esquerda bola pra direita. Pena");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! O atacante chegou na bola tremendo! Time inteiro celebrando com você!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Goleiro prum lado bola pro outro. Golaço e situação meio chata pra você...Próxima vez fale menos e faça mais!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);

                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Como um gato RAWR! Todos impressionados!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Goleiro prum lado bola pro outro. Cabeça erguida!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });
                } else if (user.getPos().equals("Zagueiro")) {
                    txtPrompt.setText("Contra-ataque veloz e você é a única coisa entre ele e o goleiro!");
                    bt1.setText("Carrinho nele!");
                    bt2.setText("Jogo de corpo");
                    bt3.setText("Solta o grito pra assusta o cara");
                    bt4.setText("puxãozinho de camisa discreto");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Carrinho limpo direto na bola!! Mandou bem demais! Os treinos valeram a pena!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Levou o drible e ficou no chão! Situação meio chata hein... Golaço");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Você chegou mais forte e tomou a bola com estilo! Olheiros do time todos de pé.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Faltou força. O atacante esticou a bola e te deixou pra traz. Golaço!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            btResults.setVisibility(View.VISIBLE);
                            int chance = rand.nextInt(101);

                            if (chance > 50) {
                                txtTitle.setText("Tática interessante, mas funcionou. Será que os olheiros gostaram?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Ta doido? Tática nada a ver. Levo caneta e ficou uma situação bem estranha.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);

                            if (chance > 50) {
                                txtTitle.setText("Os olheiros viram isso hein... não ficou muito legal...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            } else {
                                txtTitle.setText("Segue o jogo! Juiz não viu nada! Salvou o time. Não da melhor maneira, mas o que importa é o placar!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 33);
                            }
                        }
                    });
                } else if (user.getPos().equals("Meia")) {
                    txtPrompt.setText("Dois contra dois e você tá conduzindo a bola!");
                    bt1.setText("Dribla os dois pra fazer bonito");
                    bt2.setText("enfiada entre os zagueiros");
                    bt3.setText("tabelinha");
                    bt4.setText("arriscar o chute");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);

                            if (chance > 50) {
                                txtTitle.setText("Incorporou o menino Ney e deixou os zagueiros no chão! Pessoal ficou babando!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Levou o bote e perdeu a bola. Seu parça tava aberto! Ficou conhecido como o fominha.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);

                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);

                            if (chance > 50) {
                                txtTitle.setText("Passe a la Iniesta. Deixou o parça frente a frente do goleiro. De cavadinha a bola parou na rede!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Esticou demais o passe. Goleiro chegou antes. Ótima oportunidade perdida...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("No ängulo!!! Golaço que deixou todos de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Bola foi parar na arquibancada!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 60);

                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);

                            if (chance > 50) {
                                txtTitle.setText("Trabalho em equipe! Passaram pelos zagueiros e marcaram um lindo gol!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Passe interceptado! Boa tentativa, mas uma boa oportunidade desperdiçada...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });
                } else {
                    txtPrompt.setText("1 x 1 contra o goleiro! Um outro jogador do seu time vindo logo atrás de você! Goleiro crescendo e pouco tempo pra decidir o que fazer!");
                    bt1.setText("cavadinha");
                    bt2.setText("driblar o goleiro");
                    bt3.setText("tocar pro amigo fazer");
                    bt4.setText("rasteirinha no canto do gol");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Fez e fez bonito!! Bola na rede!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Pra fora! Baita gol desperdiçado!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Entrou com bola e tudo! Golaço com personalidade!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Faaaaalta! de habilidade. O goleiro defende! Baita gol desperdiçado!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 30) {
                                txtTitle.setText("Deixou o amigo sem obstáculo nenhum! Golaço!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Rolou a bola pra frente e levou impedimento! Envergonhoso...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 55);

                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Bola na rede! Com categoria!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Na trave!! Por muito pouco que não entrou. Gol desperdiçado...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });
                }
            }
        });


        bt2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtTitle.setText("Momentos finais!");

                if (user.getPos().equals("Goleiro")) {
                    txtPrompt.setText("O atacante adversário driblo o zagueiro e sofreu uma falta na area! Penalti no ultimo lance do jogo. Se eles marcarem ja era.\nVocê tem a chance de virar a estrela!");
                    bt1.setText("Pular pra direita");
                    bt2.setText(" Pular pra esquerda");
                    bt3.setText("Tira onda do atacante e pular com confiança");
                    bt4.setText("Fica sério e contar no reflexo");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            btResults.setVisibility(View.VISIBLE);
                            Random rand = new Random();
                            int chance = rand.nextInt(101);

                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Salvou o penalti e fez o povo todo aplaudir de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Goleiro pra direita bola pra esquerda. Pena");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Salvou o penalti e fez o povo todo aplaudir de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Goleiro pra esquerda bola pra direita. Pena");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! O atacante chegou na bola tremendo! Time inteiro celebrando com você!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Goleiro prum lado bola pro outro. Golaço e situação meio chata pra você...Próxima vez fale menos e faça mais!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 60);

                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Como um gato RAWR! Todos impressionados!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Goleiro prum lado bola pro outro. Cabeça erguida!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });
                } else if (user.getPos().equals("Zagueiro")) {
                    txtPrompt.setText("Contra-ataque veloz e você é a única coisa entre ele e o goleiro!");
                    bt1.setText("Carrinho nele!");
                    bt2.setText("Jogo de corpo");
                    bt3.setText("Solta o grito pra assusta o cara");
                    bt4.setText("puxãozinho de camisa discreto");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Carrinho limpo direto na bola!! Mandou bem demais!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 95);

                            } else {
                                txtTitle.setText("Levou o drible e ficou no chão! Situação meio chata hein... Golaço");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 65);

                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Você chegou mais forte e tomou a bola com estilo! Olheiros do time todos de pé.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Faltou força. O atacante esticou a bola e te deixou pra traz. Golaço!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Tática interessante, mas funcionou. Será que os olheiros gostaram?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 80);

                            } else {
                                txtTitle.setText("Ta doido? Tática nada a ver. Levo caneta e ficou uma situação bem estranha.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 30) {
                                txtTitle.setText("Os olheiros viram isso hein... não ficou muito legal...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 30);

                            } else {
                                txtTitle.setText("Segue o jogo! Juiz não viu nada! Salvou o time. Não da melhor maneira, mas o que importa é o placar!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });
                } else if (user.getPos().equals("Meia")) {
                    txtPrompt.setText("Dois contra dois e você tá conduzindo a bola!");
                    bt1.setText("Dribla os dois pra fazer bonito");
                    bt2.setText("enfiada entre os zagueiros");
                    bt3.setText("tabelinha");
                    bt4.setText("arriscar o chute");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Incorporou o menino Ney e deixou os zagueiros no chão! Pessoal ficou babando!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Levou o bote e perdeu a bola. Seu parça tava aberto! Ficou conhecido como o fominha.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 65);

                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Passe a la Iniesta. Deixou o parça frente a frente do goleiro. De cavadinha a bola parou na rede!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Esticou demais o passe. Goleiro chegou antes. Ótima oportunidade perdida...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("No ängulo!!! Golaço que deixou todos de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Bola foi parar na arquibancada!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Trabalho em equipe! Passaram pelos zagueiros e marcaram um lindo gol!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 100);

                            } else {
                                txtTitle.setText("Passe interceptado! Boa tentativa, mas uma boa oportunidade desperdiçada...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);

                            }
                        }
                    });
                } else {
                        txtPrompt.setText("1 x 1 contra o goleiro! Um outro jogador do seu time vindo logo atrás de você! Goleiro crescendo e pouco tempo pra decidir o que fazer!");
                        bt1.setText("cavadinha");
                        bt2.setText("driblar o goleiro");
                        bt3.setText("tocar pro amigo fazer");
                        bt4.setText("rasteirinha no canto do gol");

                        bt1.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Random rand = new Random();
                                int chance = rand.nextInt(101);
                                btResults.setVisibility(View.VISIBLE);
                                if (chance > 50) {
                                    txtTitle.setText("Fez e fez bonito!! Bola na rede!");
                                    txtPrompt.setVisibility(View.GONE);
                                    bt1.setVisibility(View.GONE);
                                    bt2.setVisibility(View.GONE);
                                    bt3.setVisibility(View.GONE);
                                    bt4.setVisibility(View.GONE);
                                    intent1.putExtra("User", user);
                                    intent1.putExtra("Qualidade", 100);

                                } else {
                                    txtTitle.setText("Pra fora! Baita gol desperdiçado!");
                                    txtPrompt.setVisibility(View.GONE);
                                    bt1.setVisibility(View.GONE);
                                    bt2.setVisibility(View.GONE);
                                    bt3.setVisibility(View.GONE);
                                    bt4.setVisibility(View.GONE);
                                    intent1.putExtra("User", user);
                                    intent1.putExtra("Qualidade", 60);

                                }
                            }
                        });

                        bt2.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Random rand = new Random();
                                int chance = rand.nextInt(101);
                                btResults.setVisibility(View.VISIBLE);
                                if (chance > 50) {
                                    txtTitle.setText("Entrou com bola e tudo! Golaço com personalidade!");
                                    txtPrompt.setVisibility(View.GONE);
                                    bt1.setVisibility(View.GONE);
                                    bt2.setVisibility(View.GONE);
                                    bt3.setVisibility(View.GONE);
                                    bt4.setVisibility(View.GONE);
                                    intent1.putExtra("User", user);
                                    intent1.putExtra("Qualidade", 100);

                                } else {
                                    txtTitle.setText("Faaaaalta! de habilidade. O goleiro defende! Baita gol desperdiçado!");
                                    txtPrompt.setVisibility(View.GONE);
                                    bt1.setVisibility(View.GONE);
                                    bt2.setVisibility(View.GONE);
                                    bt3.setVisibility(View.GONE);
                                    bt4.setVisibility(View.GONE);
                                    intent1.putExtra("User", user);
                                    intent1.putExtra("Qualidade", 60);

                                }
                            }
                        });

                        bt3.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Random rand = new Random();
                                int chance = rand.nextInt(101);
                                btResults.setVisibility(View.VISIBLE);
                                if (chance > 30) {
                                    txtTitle.setText("Deixou o amigo sem obstáculo nenhum! Golaço!");
                                    txtPrompt.setVisibility(View.GONE);
                                    bt1.setVisibility(View.GONE);
                                    bt2.setVisibility(View.GONE);
                                    bt3.setVisibility(View.GONE);
                                    bt4.setVisibility(View.GONE);
                                    intent1.putExtra("User", user);
                                    intent1.putExtra("Qualidade", 100);

                                } else {
                                    txtTitle.setText("Rolou a bola pra frente e levou impedimento! Envergonhoso...");
                                    txtPrompt.setVisibility(View.GONE);
                                    bt1.setVisibility(View.GONE);
                                    bt2.setVisibility(View.GONE);
                                    bt3.setVisibility(View.GONE);
                                    bt4.setVisibility(View.GONE);
                                    intent1.putExtra("User", user);
                                    intent1.putExtra("Qualidade", 40);

                                }
                            }
                        });

                        bt4.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View v) {
                                Random rand = new Random();
                                int chance = rand.nextInt(101);
                                btResults.setVisibility(View.VISIBLE);
                                if (chance > 50) {
                                    txtTitle.setText("Bola na rede! Com categoria!");
                                    txtPrompt.setVisibility(View.GONE);
                                    bt1.setVisibility(View.GONE);
                                    bt2.setVisibility(View.GONE);
                                    bt3.setVisibility(View.GONE);
                                    bt4.setVisibility(View.GONE);
                                    intent1.putExtra("User", user);
                                    intent1.putExtra("Qualidade", 100);

                                } else {
                                    txtTitle.setText("Na trave!! Por muito pouco que não entrou. Gol desperdiçado...");
                                    txtPrompt.setVisibility(View.GONE);
                                    bt1.setVisibility(View.GONE);
                                    bt2.setVisibility(View.GONE);
                                    bt3.setVisibility(View.GONE);
                                    bt4.setVisibility(View.GONE);
                                    intent1.putExtra("User", user);
                                    intent1.putExtra("Qualidade", 70);

                                }
                            }
                        });
                }
            }
        });

        bt4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtTitle.setText("Momentos finais!");
                if (user.getPos().equals("Goleiro")) {
                    txtPrompt.setText("O atacante adversário driblo o zagueiro e sofreu uma falta na area! Penalti no ultimo lance do jogo. Se eles marcarem ja era.\nVocê tem a chance de virar a estrela!");
                    bt1.setText("Pular pra direita");
                    bt2.setText(" Pular pra esquerda");
                    bt3.setText("Tira onda do atacante e pular com confiança");
                    bt4.setText("Fica sério e contar no reflexo");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Salvou o penalti e fez o povo todo aplaudir de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);

                            } else {
                                txtTitle.setText("Goleiro pra direita bola pra esquerda. Pena... No FIFA é mais fácil que da pra ver o controle do outro!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 20);

                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Salvou o penalti e fez o povo todo aplaudir de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Goleiro pra esquerda bola pra direita. Pena... No FIFA é mais fácil que da pra ver o controle do outro!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 20);

                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! O atacante chegou na bola tremendo! Time inteiro celebrando com você!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Goleiro prum lado bola pro outro. Golaço e situação meio chata pra você... Próxima vez fale menos e faça mais! No FIFA é mais fácil que da pra ver o controle do outro!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 20);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Como um gato RAWR! Todos impressionados!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Goleiro prum lado bola pro outro. Cabeça erguida! No FIFA é mais fácil que da pra ver o controle do outro!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 20);
                            }
                        }
                    });
                } else if (user.getPos().equals("Zagueiro")) {
                    txtPrompt.setText("Contra-ataque veloz e você é a única coisa entre ele e o goleiro!");
                    bt1.setText("Carrinho nele!");
                    bt2.setText("Jogo de corpo");
                    bt3.setText("Solta o grito pra assusta o cara");
                    bt4.setText("puxãozinho de camisa discreto");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Carrinho limpo direto na bola!! Mandou bem demais!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Levou o drible e ficou no chão! Situação meio chata hein... No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Você chegou mais forte e tomou a bola com estilo! Olheiros do time todos de pé.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Faltou força. O atacante esticou a bola e te deixou pra traz. No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Tática interessante, mas funcionou. Será que os olheiros gostaram?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Ta doido? Tática nada a ver. Levo caneta e ficou uma situação bem estranha. No videogame essas táticas funcionam?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 20);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Os olheiros viram isso hein... não ficou muito legal...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Segue o jogo! Juiz não viu nada! Salvou o time. Não da melhor maneira, mas o que importa é o placar!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });
                } else if (user.getPos().equals("Meia")) {
                    txtPrompt.setText("Dois contra dois e você tá conduzindo a bola!");
                    bt1.setText("Dribla os dois pra fazer bonito");
                    bt2.setText("enfiada entre os zagueiros");
                    bt3.setText("tabelinha");
                    bt4.setText("arriscar o chute");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 80) {
                                txtTitle.setText("Incorporou o menino Ney e deixou os zagueiros no chão! Pessoal ficou babando!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 60);
                            } else {
                                txtTitle.setText("Levou o bote e perdeu a bola. Seu parça tava aberto! Ficou conhecido como o fominha. No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Passe a la Iniesta. Deixou o parça frente a frente do goleiro. De cavadinha a bola parou na rede!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Esticou demais o passe. Goleiro chegou antes. Ótima oportunidade perdida... No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("No ängulo!!! Golaço que deixou todos de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Bola foi parar na arquibancada! No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Trabalho em equipe! Passaram pelos zagueiros e marcaram um lindo gol!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Passe interceptado! Boa tentativa, mas uma boa oportunidade desperdiçada... No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });
                } else {
                    txtPrompt.setText("1 x 1 contra o goleiro! Um outro jogador do seu time vindo logo atrás de você! Goleiro crescendo e pouco tempo pra decidir o que fazer!");
                    bt1.setText("cavadinha");
                    bt2.setText("driblar o goleiro");
                    bt3.setText("tocar pro amigo fazer");
                    bt4.setText("rasteirinha no canto do gol");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Fez e fez bonito!! Bola na rede!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Pra fora! Baita gol desperdiçado! No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Entrou com bola e tudo! Golaço com personalidade!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Faaaaalta! de habilidade. O goleiro defende! Baita gol desperdiçado! No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 30) {
                                txtTitle.setText("Deixou o amigo sem obstáculo nenhum! Golaço!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Rolou a bola pra frente e levou impedimento! Envergonhoso... No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Bola na rede! Com categoria!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            } else {
                                txtTitle.setText("Na trave!! Por muito pouco que não entrou. Gol desperdiçado... No FIFA é mais fácil né?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);

                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 0);
                            }
                        }
                    });
                }
            }
        });

        bt3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtTitle.setText("Momentos finais!");
                if (user.getPos().equals("Goleiro")) {
                    txtPrompt.setText("O atacante adversário driblo o zagueiro e sofreu uma falta na area! Penalti no ultimo lance do jogo. Se eles marcarem ja era.\nVocê tem a chance de virar a estrela!");
                    bt1.setText("Pular pra direita");
                    bt2.setText(" Pular pra esquerda");
                    bt3.setText("Tira onda do atacante e pular com confiança");
                    bt4.setText("Fica sério e contar no reflexo");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Salvou o penalti e fez o povo todo aplaudir de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Goleiro pra direita bola pra esquerda. Pena");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 40);
                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Salvou o penalti e fez o povo todo aplaudir de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 80);
                            } else {
                                txtTitle.setText("Goleiro pra esquerda bola pra direita. Pena");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 60);
                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! O atacante chegou na bola tremendo! Time inteiro celebrando com você!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 80);
                            } else {
                                txtTitle.setText("Goleiro prum lado bola pro outro. Golaço e situação meio chata pra você...Próxima vez fale menos e faça mais!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Defesaaaassa!! Como um gato RAWR! Todos impressionados!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Goleiro prum lado bola pro outro. Cabeça erguida!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });
                } else if (user.getPos().equals("Zagueiro")) {
                    txtPrompt.setText("Contra-ataque veloz e você é a única coisa entre ele e o goleiro!");
                    bt1.setText("Carrinho nele!");
                    bt2.setText("Jogo de corpo");
                    bt3.setText("Solta o grito pra assusta o cara");
                    bt4.setText("puxãozinho de camisa discreto");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Carrinho limpo direto na bola!! Mandou bem demais!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Levou o drible e ficou no chão! Situação meio chata hein... Golaço");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 60);
                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Você chegou mais forte e tomou a bola com estilo! Olheiros do time todos de pé.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Faltou força. O atacante esticou a bola e te deixou pra traz. Golaço!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Tática interessante, mas funcionou. Será que os olheiros gostaram?");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Ta doido? Tática nada a ver. Levo caneta e ficou uma situação bem estranha.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 50);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Os olheiros viram isso hein... não ficou muito legal...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Segue o jogo! Juiz não viu nada! Salvou o time. Não da melhor maneira, mas o que importa é o placar!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });
                } else if (user.getPos().equals("Meia")) {

                    txtPrompt.setText("Dois contra dois e você tá conduzindo a bola!");
                    bt1.setText("Dribla os dois pra fazer bonito");
                    bt2.setText("enfiada entre os zagueiros");
                    bt3.setText("tabelinha");
                    bt4.setText("arriscar o chute");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Incorporou o menino Ney e deixou os zagueiros no chão! Pessoal ficou babando!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Levou o bote e perdeu a bola. Seu parça tava aberto! Ficou conhecido como o fominha.");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Passe a la Iniesta. Deixou o parça frente a frente do goleiro. De cavadinha a bola parou na rede!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Esticou demais o passe. Goleiro chegou antes. Ótima oportunidade perdida...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("No ängulo!!! Golaço que deixou todos de pé!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Bola foi parar na arquibancada!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Trabalho em equipe! Passaram pelos zagueiros e marcaram um lindo gol!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Passe interceptado! Boa tentativa, mas uma boa oportunidade desperdiçada...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });
                } else {

                    txtPrompt.setText("1 x 1 contra o goleiro! Um outro jogador do seu time vindo logo atrás de você! Goleiro crescendo e pouco tempo pra decidir o que fazer!");
                    bt1.setText("cavadinha");
                    bt2.setText("driblar o goleiro");
                    bt3.setText("tocar pro amigo fazer");
                    bt4.setText("rasteirinha no canto do gol");

                    bt1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Fez e fez bonito!! Bola na rede!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Pra fora! Baita gol desperdiçado!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt2.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Entrou com bola e tudo! Golaço com personalidade!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Faaaaalta! de habilidade. O goleiro defende! Baita gol desperdiçado!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt3.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 30) {
                                txtTitle.setText("Deixou o amigo sem obstáculo nenhum! Golaço!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Rolou a bola pra frente e levou impedimento! Envergonhoso...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });

                    bt4.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            Random rand = new Random();
                            int chance = rand.nextInt(101);
                            btResults.setVisibility(View.VISIBLE);
                            if (chance > 50) {
                                txtTitle.setText("Bola na rede! Com categoria!");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            } else {
                                txtTitle.setText("Na trave!! Por muito pouco que não entrou. Gol desperdiçado...");
                                txtPrompt.setVisibility(View.GONE);
                                bt1.setVisibility(View.GONE);
                                bt2.setVisibility(View.GONE);
                                bt3.setVisibility(View.GONE);
                                bt4.setVisibility(View.GONE);
                                intent1.putExtra("User", user);
                                intent1.putExtra("Qualidade", 70);
                            }
                        }
                    });
                }
            }

        });
    }

}